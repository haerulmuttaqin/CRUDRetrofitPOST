<?php 

require_once 'connect.php';

$type = $_GET['item_type']; //mengambil item_type //users

if (isset($_GET['key'])) { //jika key di set //mengambil kayword //kata kuci pencarian yang di ketikan
    $key = $_GET["key"];
    if ($type == 'users') { //cek item_type apakah == users
        $query = "SELECT * FROM users WHERE name LIKE '%$key%'";
        $result = mysqli_query($conn, $query);
        $response = array();
        while( $row = mysqli_fetch_assoc($result) ){
            array_push($response, 
            array(
                'id'=>$row['id'], 
                'name'=>$row['name'], 
                'email'=>$row['email']) 
            );
        }
        echo json_encode($response);   
    }
} else { // jika kata kunci pencarian tidak di set
    if ($type == 'users') {
        $query = "SELECT * FROM users";
        $result = mysqli_query($conn, $query);
        $response = array();
        while( $row = mysqli_fetch_assoc($result) ){
            array_push($response, 
            array(
                'id'=>$row['id'], 
                'name'=>$row['name'], 
                'email'=>$row['email']) 
            );
        }
        echo json_encode($response);   
    }
}

mysqli_close($conn);

?>